# -*- coding: utf-8 -*-

from . import product_packaging
from . import stock_package_type
from . import res_company
